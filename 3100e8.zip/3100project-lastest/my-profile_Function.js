$(document).ready(function () {
  $("#Notification-ID-modal").load("notification.php");
  $("#fate-ID-modal").load("yourFate.php");
});

function editProfile(user) {
  var update = user;
  location.href = "editProfile.php";
  console.log(update);
}

function initFollow(){
  $('#followbtn').addClass("bg_blue");
  $('#followbtn').text("Unfollow");
}

function followFunction(user, target) {
  // followed previously
  if($('#followbtn').hasClass("bg_blue")){
    $('#followbtn').text("Follow");
    var choice = 1;
  } else{ // not followed previously
    $('#followbtn').text("Unfollow");
    var choice = 0;
  }
  $('#followbtn').toggleClass("bg_blue");
  $.ajax({
    type: "POST",
    url: "follow.php",
    data: {
      FollowerUserID: user,
      TargetUserID: target,
      followChoice: choice,
    },
    dataType: "json",
    success: function (data) {
      console.log('haha ', data)
      location.reload();
    },
  });
}
