<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "tinkle";
    $conn = new mysqli($servername, $username, $password, $db);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $user = @$_POST['user'];
    $tid = @$_POST['tid'];
    $sql1 = "INSERT INTO Retweet(UserID, TweetID) VALUES($user, $tid)";
    $sql2 = "UPDATE Tweet SET retweetCounter = retweetCounter + 1  WHERE TweetID = $tid";
    $result = $conn->query($sql1);
    $result = $conn->query($sql2);
    if($conn->query($sql1) == FALSE || $result == 0){
        echo "error :(";
    }
?>
