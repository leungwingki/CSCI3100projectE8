<?php
session_start();
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "tinkle";
$conn = new mysqli($servername, $username, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
                    // owner
                    $user = @$_POST['user'];
                    // partner
                    $fid = @$_POST['fid'];
                    $_SESSION["Partner"] = $fid;
                    echo "<br><form method='post' autocomplete='off'>";
                    echo "<input type='text' id='inputbox-$fid' class='chatApp__convInput' type='text' placeholder='Type a message...' required>";
                    echo "<button type='button' id='send-$fid' class ='chatApp__convButton' onClick='sendMessage($user, $fid)'>Send</form>";

?>