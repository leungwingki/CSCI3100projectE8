
<?php
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "tinkle";
    $conn = new mysqli($servername, $username, $password, $db);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }




    if(isset($_POST['FollowerUserID']) && isset($_POST['TargetUserID']) && isset($_POST['followChoice'])){
        $follower = $_POST['FollowerUserID'];
        $target = $_POST['TargetUserID'];
        $choice = $_POST['followChoice'];
        update_data($conn, $follower, $target ,$choice );
    }

    function update_data($conn,$follower, $target ,$choice){
        $query="SELECT * from `follow` WHERE FollowerUserID = $follower AND TargetUserID= $target";
        $result= mysqli_query($conn , $query);


        if(mysqli_num_rows($result)>0  && $choice==1  ){
            //unfollow case
            $update_follow ="DELETE FROM follow WHERE  FollowerUserID=$follower && TargetUserID=$target";
            $result= mysqli_query($conn,$update_follow);
            //update following/follower count
            $update_followingCount ="UPDATE user SET followingCounter =followingCounter- 1 WHERE UserID= $follower";
            $result= mysqli_query($conn,$update_followingCount);
            $update_followerCount ="UPDATE user SET followerCounter =followerCounter- 1 WHERE UserID= $target";
            $result= mysqli_query($conn,$update_followerCount);
            $_SESSION["Partner"] = null;
            echo json_encode(['cnt'=>45]);

        }else if (mysqli_num_rows($result)==0 && $choice==0){
                $update_follow ="INSERT INTO `follow` (FollowerUserID, TargetUserID) VALUES ('$follower', '$target' ) ";
                $result= mysqli_query($conn,$update_follow);
                            //update following/follower count
                $update_followingCount ="UPDATE user SET followingCounter =followingCounter+ 1 WHERE UserID= $follower";
                $result= mysqli_query($conn,$update_followingCount);
                $update_followerCount ="UPDATE user SET followerCounter =followerCounter+ 1 WHERE UserID= $target";
                $result= mysqli_query($conn,$update_followerCount);
                echo json_encode(['cnt'=>23]);

        }
    }


?>