function initColor(btn, tid){
    $('#'+btn+'Btn-'+tid).toggleClass("bg_blue");
    $('#'+btn+'Cnt-'+tid).toggleClass("tx_blue");
  }
  function likeClick(tid, user){
    //disliked previously
    if($('#dislikeBtn-'+tid).hasClass("bg_blue")){
        $('#dislikeBtn-'+tid).removeClass("bg_blue");
        var dislikeCnt = parseInt($('#dislikeCnt-'+tid).text()) - 1;
        $('#dislikeCnt-'+tid).text(dislikeCnt);
        $('#dislikeCnt-'+tid).toggleClass("tx_blue");
        $.ajax({
            type: "POST",
            url: "Likedislike.php",
            data: {user: user, tid: tid, add: 0, action: 0}
        });
    }
    var likeCnt = parseInt($('#likeCnt-'+tid).text());
    //liked previously
    if($('#likeBtn-'+tid).hasClass("bg_blue")){
      likeCnt--;
      $.ajax({
            type: "POST",
            url: "Likedislike.php",
            data: {user: user, tid: tid, add: 0, action: 1}
        });
    } else{ //not liked previously
        likeCnt++;
        $.ajax({
            type: "POST",
            url: "Likedislike.php",
            data: {user: user, tid: tid, add: 1, action: 1}
        });
    }
    $('#likeCnt-'+tid).text(likeCnt);
    $('#likeBtn-'+tid).toggleClass("bg_blue");
    $('#likeCnt-'+tid).toggleClass("tx_blue");


  }
  function dislikeClick(tid, user){
    //liked previously
    if($('#likeBtn-'+tid).hasClass("bg_blue")){
        $('#likeBtn-'+tid).removeClass("bg_blue");
        var likeCnt = parseInt($('#likeCnt-'+tid).text()) - 1;
        $('#likeCnt-'+tid).text(likeCnt);
        $('#likeCnt-'+tid).toggleClass("tx_blue");
        $.ajax({
            type: "POST",
            url: "Likedislike.php",
            data: {user: user, tid: tid, add: 0, action: 1}
        });
    }
    var dislikeCnt = parseInt($('#dislikeCnt-'+tid).text());
    //disliked previously
    if($('#dislikeBtn-'+tid).hasClass("bg_blue")){
        dislikeCnt--;
        $.ajax({
            type: "POST",
            url: "Likedislike.php",
            data: {user: user, tid: tid, add: 0, action: 0}
        });
    } else{ //not disiked previously
        dislikeCnt++;
        $.ajax({
            type: "POST",
            url: "Likedislike.php",
            data: {user: user, tid: tid, add: 1, action: 0}
        });
    }
    $('#dislikeCnt-'+tid).text(dislikeCnt);
    $('#dislikeBtn-'+tid).toggleClass("bg_blue");
    $('#dislikeCnt-'+tid).toggleClass("tx_blue");

  }
  function retweetClick(tid, user){
    if($('#retweetBtn-'+tid).hasClass("bg_blue")){

    }
    else{
      $.ajax({
        type: "POST",
        url: "Retweet.php",
        data: {user: user, tid: tid},
      });
      var retweetCnt = parseInt($('#retweetCnt-'+tid).text()) + 1;
      $('#retweetCnt-'+tid).text(retweetCnt);
      $('#retweetBtn-'+tid).toggleClass("bg_blue");
      $('#retweetCnt-'+tid).toggleClass("tx_blue");
    }
  }
  function displayChat(user, fid){
    $.ajax({
      type: "POST",
      url: "Messages.php",
      datatype: "html",
      data: {user: user, fid: fid},
      success: function(response){
        $("#chatroom").html(response);
      }
    });
  }
  //global variable
  var autorefresh = -1;
  function changeChat(user, fid){
    if(autorefresh != -1){
        clearInterval(autorefresh);
    }
    $('.ListItem').removeClass("bg_blue");
    $('#chatitem-'+fid).addClass("bg_blue");
    displayChat(user,fid);
    autorefresh = setInterval(() => displayChat(user, fid), 3000);
    $.ajax({
        type: "POST",
        url: "Typemessage.php",
        datatype: "html",
        data: {user: user, fid: fid},
        success: function(response){
            $("#sendbox").html(response);
        }
    });
  }
  function sendMessage(user, fid){
    var input = $("#inputbox-"+fid).val();
    if(input != null && input != "" && input != " "){
        $.ajax({
            type: "POST",
            url: "Sendmessage.php",
            datatype: "html",
            data: {user: user, fid: fid, text: input},
            success: function(){
                $("#inputbox-"+fid).val(" ");
                displayChat(user,fid);
            }
        });
    }
  }
  // no action on pressing enter
  $(document).ready(function() {
    $(window).keydown(function(event){
        if(event.keyCode == 13) {
        event.preventDefault();
        return false;
        }
    });
});