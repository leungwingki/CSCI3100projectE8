<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "tinkle";
    $conn = new mysqli($servername, $username, $password, $db);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // owner
    $A = @$_POST['user'];
    // partner
    $B = @$_POST['fid'];
    echo "<script>var element = document.getElementById('chatroom'); element.scrollTop = element.scrollHeight;</script><br>";
    $sql = "SELECT Text, FromUserID, ToUserID, DateTime FROM PrivateMessage WHERE (FromUserID = $A AND ToUserID = $B) OR (FromUserID = $B AND ToUserID = $A) ORDER BY DateTime ASC";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $message = $row["Text"];
            if($row["FromUserID"] == $A){
                echo "<div class = 'chatApp__convMessageItem chatApp__convMessageItem--right clearfix'>";
                echo "<div class = 'chatApp__convMessageValue'> $message </div> ";
                echo "</div>";
            } else{
                echo "<div class = 'chatApp__convMessageItem chatApp__convMessageItem--left clearfix'>";
                echo "<div class = 'chatApp__convMessageValue'> $message </div> ";
                echo "</div>";
            }
        }
    }

?>
