<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet"
		href="my-profile.css">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script language="JavaScript" type="text/javascript" src = "my-profile_Function.js" > </script>
       
</head>
<body>
    <div class="BIGcontainer">
        <div class="sidebar" >
               <div ><img src="LOGO.png" class="logo"></div>
               <div>
			   <form method="post">
			   <input class="searchforuser" type="text" placeholder="Username" name="search">
                 <button type="submit" name="submit" class="fa-fa-search" >Search</button>
				</form>
               </div>

               <?php 

$servername = "localhost";
$username = "root";
$password = "";
$db = "tinkle";
$conn = new mysqli($servername, $username, $password, $db);
			   
			   if(isset($_POST["submit"])){
				
				$str = $_POST["search"];
				$sth = "SELECT UserID FROM user WHERE Username='$str'";
				$result =$conn->query($sth);
       
				if($row = $result->fetch_array()){
        
          $_SESSION["targetuser"] = $row[0];
					
          header('Location: my-profile-others.php');

				}else{

					echo"Username do not exisit";

				}
     

			   }

?>
               
               <button id="switchpageHome"><img src="home.png"></button>
               <script type="text/javascript">
                document.getElementById("switchpageHome").onclick = function () {
                    location.href = "twitter.php";
                };
            </script>
                <button id="LinkFate" type="button" data-toggle="modal" data-target="#exampleModalCenter">
                <img class ="PopFortune" src="notifications.png">
                </button>
           
                <button id="switchpageTreehole" ><img src="treehole.png"></button>
               <script type="text/javascript">
                document.getElementById("switchpageTreehole").onclick = function () {
                    location.href = "treehole.php";   
                };
                </script>

                
                <button id="LinkFortune" type="button"  data-toggle="modal" data-target="#exampleModal"><img class ="PopFortune"
                                src="dailyfortune.png"></button>


              
               <button id="switchpageDrawForFate" type="button"  data-toggle="modal" data-target="#myModal" ><img src="drawforfate.png"></button>
               <!-- <script type="text/javascript">
                document.getElementById("switchpageDrawForFate").onclick = function () {
                    location.href = "yourFate.php";   
                };
                </script> -->


               <button id="switchpageProfile" ><img src="profile.png"></button>
               <script type="text/javascript">
                document.getElementById("switchpageProfile").onclick = function () {
                    location.href = "my-profile.php";   
                };
                </script>
               
               
               <button id="switchpageSetting" ><img src="setting.png"></button>
               <script type="text/javascript">
                document.getElementById("switchpageSetting").onclick = function () {
                    location.href = "setting.php";   
                };
                </script>

                            
                <button id="switchpageCreateTweet" ><img src="Tweet.png" class="Tweet"></button>
                            <script type="text/javascript">
                            document.getElementById("switchpageCreateTweet").onclick = function () {
                                location.href = "CreateTweet.php";   
                            };
                            </script>
                </div>
    
   
    
        <div class="Home">
            <div class='HomeTop'>
            <!-- Start PHP -->
            <?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$db = "tinkle";
					$conn = new mysqli($servername, $username, $password, $db);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					$user = $_SESSION['UserID'];
					// display His Bio 
					$user_profile = "SELECT  User.Username,User.Icon, User.Cover, User.Bio, User.followerCounter, User.followingCounter FROM  User WHERE UserID =$user ";
					$result_profile = $conn->query($user_profile);
					date_default_timezone_set('Asia/Hong_Kong');
					// print
					while($row = $result_profile->fetch_array()) {
						$username = $row[0];
						$usericon = $row[1];
						$usercover = $row[2];
						$userbio = $row[3];
						$userfollower = $row[4];
						$userfollowing = $row[5];

   


						echo "<div class='name'>@$username</div>";
						echo "<div class='NoFollower'> $userfollower Followers</div><div class='NoFollowing'> $userfollowing Following</div></div>";
                        echo "<div class='profile-container'><div class='profile-container-cover-n-profile-pic'>";
                        if($usercover != null){
							echo "<img class='profile-container-cover' src='data:image;base64,".base64_encode($usercover). "' alt='Cover Picture' />";
						}

                        if($usercover == null){
                            echo "<img class='profile-container-cover' src='default_Cover.webp' />";
                            // have a container but display no pic
                            // echo "<img class='profile-container-cover' class='no-media' />";
                        }
                        
                        echo "<div class='profile-picture-circle' >";
                        if($usericon != null){
							echo "<img class='profile-picture-circle-pic' src='data:image;base64,".base64_encode($usericon). "' alt='Profile Picture' />";
						}

                        if($usericon == null){
                            echo "<img  class='no-media' />";
                        }
                        
                        echo "</div><div class='profile-bio'><div class='username-id'><ul>@$username</ul></div>";
						echo "<div class='username-id-bio'><ul>$userbio</ul></div></div>";
                    }

                    echo "<form method = 'get'><div class='action-under-profile'><button class='action-under-profile-column1' name='edit' onclick=\"editProfile($user)\" > Edit Profile </button>";
                    echo "<button class='action-under-profile-column2' name='all-tweet'  >Tweets </button>";
                    echo "<button class='action-under-profile-column3' name='all-retweet' > Retweet</button>";
                    echo "</div></div></div>";

                    if(isset($_GET['edit'])){
                        echo " <form method = 'get'><div class='editClass'><select class='edit ' id='editChoice' onChange=\"editChoiceFunction($user);\" > 
                        <option value='0'>Edit Icon</option> <option value='1'> Edit username</option></select> </div>";


                        // echo"<form method = 'get'><div class='setting_box'><div class='setting_title'><span>Edit Profile</span></div>";
                        // echo"<div class='btn01' onclick=\"editICON();\"><span> Edit Icon</span></div>";
                        // echo"<div class='btn02' onclick=\"editUSERNAME();\"><span> Edit Username</span></div>";
                        // echo"<div class='btn03' onclick=\"editBIO();\"><span> Edit Bio</span></div>";
                        // echo"<div class='btn04' onclick=\"editCOVER();\"><span> Edit Cover</span></div></div>";


                    }else if(isset($_GET['all-retweet'])){
                        $sql = "SELECT p. *, c.Text, c.Image_Video, c.LikeCounter,c.DislikeCounter,c.RetweetCounter,c.CommentCounter ,c.UserID,
                        k.Username,k.Icon FROM `retweet` AS p 
                        LEFT JOIN `tweet` AS c ON p.TweetID = c.TweetID 
                        LEFT JOIN `user` AS k ON c.UserID = k.UserID
                        WHERE p.UserID = $user ORDER BY DateTime DESC";
                        $result = $conn->query($sql);
                        date_default_timezone_set('Asia/Hong_Kong');
                        while($row = $result->fetch_array()) {
                            $whoretweet_userid = $row[0]; //useless
                            $tweetid=$row[1];
                            $elapsed = time() - strtotime($row[2]);
                            $message = $row[3];
                            $pic = $row[4];
                            $upc = $row[5];
                            $downc = $row[6];
                            $rec = $row[7];
                            $comc = $row[8];
                            $beingretweet_userid = $row[9]; //useless
                            $name = $row[10];
                            $usericon = $row[11];
                            
                            if($elapsed < 60){
                                $elapsed = $elapsed . 's';
                            } elseif($elapsed < 60*60){
                                $elapsed = ((int) ($elapsed / 60)) . 'm';
                            } elseif($elapsed < 60*60*24){
                                $elapsed = ((int) ($elapsed / 60 / 60)) . 'h';
                            } elseif($elapsed < 60*60*24*7){
                                $elapsed = ((int) ($elapsed / 60 / 60 / 24)) . 'd';
                            } else{
                                $elapsed = ((int) ($elapsed / 60 / 60 / 24 / 7)) . 'w';
                            }


                            echo "<div class='container'><div class='side'><div class='avatar-medium-1'>";
                            echo "<img class='profile-picture-1' src='data:image;base64,".base64_encode($usericon). "' alt='Profile Picture' /> </div></div>";
                            echo "<div class='main'><ul class='user'><li class='UserName' > @$name </li>";
                            echo "<li class = 'TimeStamp'> $elapsed </li></ul>";
                            echo "<ul class = 'text-content'><li> $message </li></ul>";
                            if($pic != null){
                                echo "<ul class = 'media'><li><img src='data:image;base64,".base64_encode($pic). "' alt='Post Picture' /></li></ul>";
                            }else{
                                echo "<ul class = 'no-media'><li></li></ul>";
                            }
                            

                            // get like/dislike status
                            
                            echo "<form method = 'post'> <ul class='action_-item'>  <li> <button type='button' name='inter1' onclick=\"displayLike();\" >";
                            echo "<img class='interactimg_1' src='Like.png'> </button> </li><li class='LikeCount' > $upc </li>";
                            echo "<li> <button type='button' name='inter2' ' > <img class='interactimg_2' src='Dislike.png'> </button> </li><li class = 'DislikeCount'> $downc </li>";
                            echo "<li> <button type='button' name='inter3'> <img class='interactimg_3' src='Comment.png'> </button> </li><li class='CommentCount'> $comc </li>";
                            echo "<li> <button type='button' name='inter4'> <img class='interactimg_4' src='Retweet.png'> </button> </li><li class='RetweetCount'> $comc </li>  </ul> </form>";
                            echo "</div></div>";
                        }
                        }else{
                            //
                            $reload_tweet = "SELECT p. *, c.Username, c.Icon FROM `tweet` AS p LEFT JOIN `user` AS c ON p.UserID = c.UserID WHERE p.UserID = $user ORDER BY DateTime DESC";
                            $result = $conn->query($reload_tweet);
                            date_default_timezone_set('Asia/Hong_Kong');
                            while($row = $result->fetch_array()) {
                                $id = $row[0];
                                $userid=$row[1];
                                $message = $row[2];
                                $pic = $row[3];
                                $upc = $row[4];
                                $downc = $row[5];
                                $rec = $row[6];
                                $comc = $row[7];
                                $name = $row[9];
                                $usericon = $row[10];
                                $elapsed = time() - strtotime($row[8]);
                                if($elapsed < 60){
                                    $elapsed = $elapsed . 's';
                                } elseif($elapsed < 60*60){
                                    $elapsed = ((int) ($elapsed / 60)) . 'm';
                                } elseif($elapsed < 60*60*24){
                                    $elapsed = ((int) ($elapsed / 60 / 60)) . 'h';
                                } elseif($elapsed < 60*60*24*7){
                                    $elapsed = ((int) ($elapsed / 60 / 60 / 24)) . 'd';
                                } else{
                                    $elapsed = ((int) ($elapsed / 60 / 60 / 24 / 7)) . 'w';
                                }


                                echo "<div class='container'><div class='side'><div class='avatar-medium-1'>";
                                echo "<img class='profile-picture-1' src='data:image;base64,".base64_encode($usericon). "' alt='Profile Picture' /> </div></div>";
                                echo "<div class='main'><ul class='user'><li class='UserName' > @$name </li>";
                                echo "<li class = 'TimeStamp'> $elapsed </li></ul>";
                                echo "<ul class = 'text-content'><li> $message </li></ul>";
                                if($pic != null){
                                    echo "<ul class = 'media'><li><img src='data:image;base64,".base64_encode($pic). "' alt='Post Picture' /></li></ul>";
                                }else{
                                    echo "<ul class = 'no-media'><li></li></ul>";
                                }
                                

                                // get like/dislike status
                                
                                echo "<form method = 'post'> <ul class='action_-item'>  <li> <button type='button' name='inter1' onclick=\"displayLike();\" >";
                                echo "<img class='interactimg_1' src='Like.png'> </button> </li><li class='LikeCount' > $upc </li>";
                                echo "<li> <button type='button' name='inter2' ' > <img class='interactimg_2' src='Dislike.png'> </button> </li><li class = 'DislikeCount'> $downc </li>";
                                echo "<li> <button type='button' name='inter3'> <img class='interactimg_3' src='Comment.png'> </button> </li><li class='CommentCount'> $comc </li>";
                                echo "<li> <button type='button' name='inter4'> <img class='interactimg_4' src='Retweet.png'> </button> </li><li class='RetweetCount'> $comc </li>  </ul> </form>";
                                echo "</div></div>";
                            }
                        }





				?>
                
                
      
        </div>
        <div class="Chat" >
           
                <div class="ChatList">
                    
                    <div class="ChatListTop">Conversations
                        <img src="ADDCHAT.png" class="addchat">
                    </div>
                     

                    <div class="ListItem">
                        
                        <div class="Listside">
                        <div class="avatar-medium-1">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                        </div>
                            <div class="ListUserName" > James No.1 
                                <img src="sendmessage.png" class="sendbutton"></div>
                        </div>
                        </div>

                        <div class="ListItem">
                        
                            <div class="Listside">
                            <div class="avatar-medium-1">
                            <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                            </div>
                                <div class="ListUserName" > James No.2<img src="sendmessage.png" class="sendbutton"></div>
                            </div>
                            </div>
                   <div class="ListItem">
                        
                        <div class="Listside">
                        <div class="avatar-medium-1">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                        </div>
                            <div class="ListUserName" > James No.243<img src="sendmessage.png" class="sendbutton"></div>
                        </div>
                        </div>
                    <div class="ListItem">
                        
                        <div class="Listside">
                        <div class="avatar-medium-1">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                        </div>
                            <div class="ListUserName" > James No.342<img src="sendmessage.png" class="sendbutton"></div>
                        </div>
                        </div>
                    <div class="ListItem">
                        
                        <div class="Listside">
                        <div class="avatar-medium-1">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                        </div>
                            <div class="ListUserName" > James No.441<img src="sendmessage.png" class="sendbutton"></div>
                        </div>
                        </div>
                  
                 
            </div>
                <div class="Conversations">
                    <div>hi</div>
                     <div>hi</div>
                    <div>hi</div>
                    <div>hi</div>
                </div>
        </div>
    </div>    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
 
    
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalCenterTitle">Your Notification!</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
                    </div>
                        <div class="modal-body" id="Notification-ID-modal" >
                    </div>
          </div>
        </div>
    </div>




<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="myModalTitle">Your Fate!</h5>
              <button id="fateButton" type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
                    <div class="modal-body" id="1">
                        <iframe src="yourFate.php" ></iframe>
                    </div> 
            <!-- <div class="modal-body" id="fate-ID-modal" ></div> -->
            </div>
          </div>
        </div>
    </div>



    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Your Fortune!</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div id ="2" class="modal-body">
            <iframe src="Fortune.php">
          </div>

        </div>
      </div>
    </div>

    
    </body>

</html>

