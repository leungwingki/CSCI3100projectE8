<!DOCTYPE html>
<html>

<head>
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="style.css">

</head>

<body>
		<?php
$servername = "localhost";
$username = "root";
$password = "usbw";
$db = "tinkle";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// owner
$A = 4;
// partner
$B = 5;
$sql = "SELECT Username FROM User WHERE UserId = $A";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$Aname = $row["Username"];
$sql = "SELECT Username FROM User WHERE UserId = $B";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$Bname = $row["Username"];
echo "<div class= 'chatApp__convTitle'> $Bname </div>";

$sql = "SELECT Text, FromUserID, ToUserID, DateTime FROM PrivateMessage WHERE (FromUserID = $A AND ToUserID = $B) OR (FromUserID = $B AND ToUserID = $A) ORDER BY DateTime ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  $messages = array();
  while($row = $result->fetch_assoc()) {
	$message = $row["Text"];
	if($row["FromUserID"] == $A){
		echo "<div class = 'chatApp__convMessageItem chatApp__convMessageItem--right clearfix'>";
		echo "<div class = 'chatApp__convMessageValue'> $message </div> ";
		echo "</div>";
	} else{
		echo "<div class = 'chatApp__convMessageItem chatApp__convMessageItem--left clearfix'>";
		echo "<div class = 'chatApp__convMessageValue'> $message </div> ";
		echo "</div>";
	}
    $messages[] = $row;

  }
} else {
  echo "<p>no messages yet</p>";
}
echo "<form>";
echo "<input class='chatApp__convInput' type='text' placeholder='Type a message...'>";
echo "<div class ='chatApp__convButton'>Send</div>";
echo "</form>";
?>


</body>

</html>