<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title></title>
	</head>
	<body>
        <div id="my-popup">
            <div style="position: absolute;"  id="leave_box">
                <div class="setting_box">
                    <div class="setting_title">
                        <span>Leave a comment!</span>
                    </div>
                    
                    <ul class="quiz">
                        <li>
                            <div class="space">
                            </div>
                            <div class="input_box">
                               
                                <div class="btn" onclick="opensend()">
                                </div>
                            </div>

                          
<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "tinkle";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// id
$tid = 1;
$uid=2;

$sql = "SELECT a.*, b.Username, b.Icon FROM tweetComment a, User b WHERE TweetID=$tid AND a.UserID=b.UserID ORDER BY CommentID";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $msg = $row["Text"];
    $ic=$row["Icon"];
    $us=$row["Username"];
    echo"<ul class='choices'>";
    echo"<li>";
    echo"<div class='notification_message'>";
    echo"<div class='notification_icon'>";
    echo"<img class='profile-picture-1' src='$ic' />";
    echo"</div>";
    echo"<ul class ='name_word'>$us</ul>";
    echo"<ul class ='notification_word'> $msg</ul>";
    echo"</div>";
    echo"</li>";
    echo"</ul>";
      }
    }
      
      if(isset($_POST["send"])){
          if($_POST["inputbox"] != ""){
              $new = $_POST["inputbox"];
              $sql = "INSERT INTO tweetComment(UserID, TweetID, Text) VALUES($uid,$tid, '$new')";
              if($conn->query($sql) == FALSE){
                  echo "error :(";
              } else{
                  echo "<script type='text/javascript'> if(window.history.replaceState) {window.history.replaceState(null, null, window.location.href);}</script>}";
                  echo "<script type='text/javascript'>window.location.reload();</script>";
              }
          }
      }
      
?>
<form method="POST">
<li>
    <input type="text" name="inputbox" size="30" placeholder="Type your thoughts here..."  style="width: 100px;height:500px;line-height:40px;font-size: 20px;margin-top: 10px;margin-left: 40px;"/>
</li>


<button type="submit" name="send" class="btn02" >Post Comment</button>

</form>


                </div>
                
                <div class="close_box" onclick="closeleave()"></div>
            </div>
			
		</div>
	</body>
</html>
<style>
	*{
		padding: 0;
		margin: 0;
		user-select: none;
	}
    


    .notification_icon {
        display: block;
      border-radius: 999999px;
      height: 49px;
      width: 49px;
      overflow: hidden;
      position: relative;
      width: 49px;
    }

    .profile-picture-1 {
      height: 49px;
      left: 0;
      object-fit: cover;
      position: absolute;
      top: 1px;
      width: 49px;
    }
    .name_word {
        width: 88%;
        height: 25px;
        left: 55px;
        /* margin: 10px 20px; */
        text-align: left;
        bottom:50px;
        overflow: hidden;
        position: relative;
    }
    .notification_word {
        width: 88%;
        height: 60px;
        left: 55px;
        /* margin: 10px 20px; */
        text-align: left;
        bottom:50px;
        overflow: hidden;
        position: relative;
    }

    .notification_message {
      display: block;
      background-color: white;
      width: 95%;
      height: 60px;
      border-bottom: 2px solid rgb(159, 156, 156);
      margin-top: 5px;
      margin-left: 5px;
      background-size: 100% 100%;
      font-size: 18px;
      font-weight: 20;
      line-height: 24px;
      color: rgb(31, 31, 31);
    }

    
	.box{
		width: 100vw;
		height: 100vh;
		background-image: url('./img/bgImg.png');
	}
    .btn01{
        color:white;
        background-image: url('img/button.png');
        background-size: 100% 100%;
        display:block;
        width:400px;
        margin:100px auto;
        font-size:30px;
        font-weight:800;
        height:70px;
        line-height:70px;
        text-align:center;
    }
    
    .space{
        color:white;
        display:block;
        width:400px;
        margin:10px auto;
        font-size:30px;
        font-weight:800;
        height:10px;
        line-height:70px;
        text-align:center;
    }


    .btn02{
        color:white;
        background-image: url('img/button.png');
        background-size: 100% 100%;
        display:block;
        width:400px;
        margin:20px auto;
        font-size:30px;
        font-weight:800;
        height:70px;
        line-height:70px;
        text-align:center;}
    

    
    .setting_box{
        width: 500px;
        height: 500px;
        position: absolute;
        padding: 5px;
        top: 200px;
        left: calc(50vw - 250px);
        border: #288cc6 15px solid;
        border-radius: 30px;
        background-color: white;
        z-index: 3;
        overflow-y: auto;
        overflow-x: hidden;
        padding-top: 60px;
        padding-bottom: 30px;
        box-sizing: border-box;
    }
    
    
    .setting_title{
        width: 500px;
        height: 100px;
        margin: 30px auto;
        color: #288cc6;
        font-size: 50px;
        font-weight: 800;
        line-height: 50px;
        text-align: center;
        position: fixed;
        top: 220px;
        left: calc(50vw - 250px);
    }
    

	
    .send_title{
        width: 400px;
        height: 400px;
        margin: 30px auto;
        color: #288cc6;
        font-size: 50px;
        font-weight: 800;
        line-height: 50px;
        text-align: center;
        position: fixed;
        top: 350px;
        left: calc(50vw - 200px);
    }
    
	.openTxt{
		width: 200px;
		height: 100px;
		line-height: 100px;
		background: wheat;
		border-radius: 30px;
		position: absolute;
		top: 400px;
		left: calc(50vw - 100px);
		z-index: 1;
		font-size: 22px;
		font-weight: 1000;
		text-align: center;
		color: midnightblue;
		font-family: 'Courier New', Courier, monospace;
	}
	

    .comment_box{
        width: 350px;
        height: 300px;
        color: white;
        background-size: 100% 100%;
        position: fixed;
        top: 300px;
        left: calc(50vw - 180px);
        border-radius: 10px;
    }


	
	/*close chat box button*/
	.close_box{
		width: 50px;
		height: 50px;
		/* background: powderblue; */
		position: absolute;
		left: calc(50vw + 195px);
		top: 210px;
		background-image: url('img/close.png');
		background-size: 100% 100%;
		z-index: 4;
	}
    
    .my-popup{
        Width: 600px;
        Height: 400px;
        Background: gray;
        Box-sizing: border-box; /* for inside padding */
        Padding: 10px;

        /* for center */
        Position:absolute;
        top:50%;
        left:50%;
        Transform: translate(-50%,-50%);

        /* for hider */
        display:none;
    }
        
</style>

<script>
    
    function showPopUp(){
        my_popup.style.display="block";
    }
    setTimeout(showPopUp,60000);
        
        function opentreehole_choice(){
            console.log(333)
            document.getElementById('choose_box').style.display = 'block'
        }
    
	function closetreehole(){
		document.getElementById('box').style.display = 'none'
	}


    
    function openleavemsg(){
        console.log(333)
        document.getElementById('leave_box').style.display = 'block'
    }
    function closeleave(){
        location.href = "twitter.php";
        document.getElementById('leave_box').style.display = 'none'
    }
    function opensend(){
        closetreehole()
        closeleave()
        console.log(333)
        document.getElementById('send_box').style.display = 'block'
    }
    function closesend(){
        location.href = "twitter.php";
        document.getElementById('send_box').style.display = 'none'
        
    }
</script>
