$(document).ready(function () {
  $("#Notification-ID-modal").load("notification.php");
  $("#fate-ID-modal").load("yourFate.php");
});

function displayLike() {
  document.getElementsByClassName("interactimg").src = "likeRedHeart.png";
}


