<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet"
		href="HomePageStyle.css">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
    
       
</head>
<body>
    <div class="BIGcontainer">
        <div class="sidebar" >
               <div ><img src="LOGO.png" class="logo"></div>
               <div><input class="searchforuser" type="text" placeholder="Username">
                   <button type="submit"><i class="fa fa-search">Search</i></button>
               </div>
               
               <button><img src="home.png"></button>
               <button><img src="notifications.png"></button>
               <button><img src="treehole.png"></button>
               <button id="LinkFortune" type="button"  data-toggle="modal" data-target="#exampleModal"><img class ="PopFortune"
                src="dailyfortune.png"></button>
        

               <button><img src="drawforfate.png"></button>
        
               
               <button><img src="profile.png"></button>
               <button><img src="setting.png"></button>
               <button><img src="Tweet.png" class="Tweet"></button>
        </div>
    
       
     
        <div class="Home">

            
            <div class="HomeTop">Home</div>
                <div class="container">
                     <div class="side">
                <div class="avatar-medium-1">
                <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </div>
                    </div> 

                <div class="main">

                <ul class="user">
                <li class="UserName" > Devon Lane</li>
                 <li class="TimeStamp" > 23s</li>
                 </ul>

                 <ul class="text-content">
                <li >I hate CS.AHHHHHhhhHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH</li>
                </ul> 

                <ul class="media">
                    <li>
                        <img src="th.jpeg">
                    </li>
                </ul>

                <ul class="action_-item">
                    <li  > <img class="CommentBotton" src="Comment.png"></li>
                     <li class="CommentCount" > 23</li>
                    
                     <li  > <img class="LikeBotton" src="Like.png"></li>
                     <li class="LikeCount" > 67</li>

                     <li  > <img class="DilikeBotton" src="Dislike.png"></li>
                     
                    
                     <li  > <img class="RetweetBotton" src="Retweet.png"></li>
                    
                     </ul>
            
               
                
                    
                    
                    
                    </div>


               
                            
                </div> 
                

                <div class="container">
                    <div class="side">
               <div class="avatar-medium-1">
               <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </div>
                   </div> 

               <div class="main">

               <ul class="user">
               <li class="UserName" > Devon Lane</li>
                <li class="TimeStamp" > 23s</li>
                </ul>

                <ul class="text-content">
               <li >ALL I want is sleepppppppppppppppppppppppppppppppppppppppp.</li>
               </ul> 

               <ul class="media">
                   <li>
                       <img src="Sleep.jpeg">
                   </li>
               </ul>

               <ul class="action_-item">
                   <li class="CommentBotton" > <img src="Comment.png"></li>
                    <li class="CommentCount" > 23</li>
                   
                    <li class="LikeBotton" > <img src="Like.png"></li>
                    <li class="LikeCount" > 67</li>

                    <li class="DilikeBotton" > <img src="Dislike.png"></li>
                    
                   
                    <li class="RetweetBotton" > <img src="Retweet.png"></li>
                   
                    </ul>
           
              
               
                   
                   
                   
                   </div>


              
                           
               </div> 
               


               <div class="container">
                <div class="side">
           <div class="avatar-medium-1">
           <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </div>
               </div> 

           <div class="main">

           <ul class="user">
           <li class="UserName" > Devon Lane</li>
            <li class="TimeStamp" > 23s</li>
            </ul>

            <ul class="text-content">
           <li >DLLM on9 project.</li>
           </ul> 

           <ul class="media">
               <li>
                   <img src="Mad.jpeg">
               </li>
           </ul>

           <ul class="action_-item">
               <li  > <img class="CommentBotton" src="Comment.png"></li>
                <li class="CommentCount" > 23</li>
               
                <li class="LikeBotton" > <img src="Like.png"></li>
                <li class="LikeCount" > 67</li>

                <li class="DilikeBotton" > <img src="Dislike.png"></li>
                
               
                <li class="RetweetBotton" > <img src="Retweet.png"></li>
               
                </ul>
       
          
           
               
               
               
               </div>


          
                       
           </div> 
           
                
                
      
        </div>
        <div class="Chat" >
           
                <div class="ChatList">
                    
                    <div class="ChatListTop">Conversations
                        <img src="ADDCHAT.png" class="addchat">
                    </div>
                     

                    <div class="ListItem">
                        
                        <div class="Listside">
                        <div class="avatar-medium-1">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                        </div>
                            <div class="ListUserName" > James No.1 
                                <img src="sendmessage.png" class="sendbutton"></div>
                        </div>
                        </div>

                        <div class="ListItem">
                        
                            <div class="Listside">
                            <div class="avatar-medium-1">
                            <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                            </div>
                                <div class="ListUserName" > James No.2<img src="sendmessage.png" class="sendbutton"></div>
                            </div>
                            </div>
                   <div class="ListItem">
                        
                        <div class="Listside">
                        <div class="avatar-medium-1">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                        </div>
                            <div class="ListUserName" > James No.243<img src="sendmessage.png" class="sendbutton"></div>
                        </div>
                        </div>
                    <div class="ListItem">
                        
                        <div class="Listside">
                        <div class="avatar-medium-1">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                        </div>
                            <div class="ListUserName" > James No.342<img src="sendmessage.png" class="sendbutton"></div>
                        </div>
                        </div>
                    <div class="ListItem">
                        
                        <div class="Listside">
                        <div class="avatar-medium-1">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> </li>
                        </div>
                            <div class="ListUserName" > James No.441<img src="sendmessage.png" class="sendbutton"></div>
                        </div>
                        </div>
                  
                 
            </div>
                <div class="Conversations">
                    <div>hi</div>
                     <div>hi</div>
                    <div>hi</div>
                    <div>hi</div>
                </div>
        </div>
    </div>    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
  
   
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Your Fortune!</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <iframe src="Fortune.php">
          </div>
          
        </div>
      </div>
    </div>
    </body>
</html>
    