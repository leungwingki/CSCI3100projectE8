$(window).load(function(){
    $('#exampleModal').modal('show');
});