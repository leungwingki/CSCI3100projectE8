<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title></title>
  </head>
  <body>
    <div class="box">

    <?php
    			$servername = "localhost";
					$username = "root";
					$password = "";
					$db = "tinkle";
					$conn = new mysqli($servername, $username, $password, $db);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
					$user = 4;


          //try to get like and dislike for notification pop up
          $notification_like = "SELECT m.*, u1.username, u1.icon, u2.text, u2.UserID
          FROM likes_dislikes m 
          INNER JOIN user u1 ON (m.UserID = u1.UserID)
          INNER JOIN tweet u2 ON (m.TweetID = u2.TweetID)
          WHERE m.Like_Dislike =1";

          $notification_follow ="SELECT m.*, u1.username, u1.icon 
          FROM follow m 
          INNER JOIN user u1 ON (m.FollowerUserID = u1.UserID)
          WHERE m.TargetUserID =$user";

          $result_notification_like = $conn->query($notification_like);
          $result_notification_follow = $conn->query($notification_follow);
          date_default_timezone_set('Asia/Hong_Kong');
          echo "<div class ='box'><div class='treehole_box'><div class='treehole_title'><span>Notification!</span></div>";
                    // print
          while($row_notification = $result_notification_like->fetch_array()) {
            $whoLikeyouID = $row_notification[0];
            // $tweetID = $row_notification[1];
            $elapsed = time() - strtotime($row_notification[3]);
            $whoLikeyouUsername = $row_notification[4];
            $whoLikeyouUserIcon = $row_notification[5];
            $tweetContent = $row_notification[6];
            $userPostedTweet = $row_notification[7];
            if($elapsed < 60){
              $elapsed = $elapsed . 's';
            } elseif($elapsed < 60*60){
              $elapsed = ((int) ($elapsed / 60)) . 'm';
            } elseif($elapsed < 60*60*24){
              $elapsed = ((int) ($elapsed / 60 / 60)) . 'h';
            } elseif($elapsed < 60*60*24*7){
              $elapsed = ((int) ($elapsed / 60 / 60 / 24)) . 'd';
            } else{
              $elapsed = ((int) ($elapsed / 60 / 60 / 24 / 7)) . 'w';
            }
            if($userPostedTweet!= $whoLikeyouID && $userPostedTweet==$user){
                echo "<div class='notification_message'><div class='notification_icon'><img class='profile-picture-1' src='data:image;base64,".base64_encode($whoLikeyouUserIcon). "' alt='Profile Picture' /> </div><ul class='notification_word'> $whoLikeyouUsername like your tweets. </ul>" ;
                echo "<ul class = 'notification_time'> $elapsed </ul></div>";
                
    
    
              }
            
            }


            while($follow_notification = $result_notification_follow->fetch_array()) {
              $elapsed = time() - strtotime($follow_notification[2]);
              $whofollowyou = $follow_notification[3];
              $whofollowyouICON = $follow_notification[4];
              if($elapsed < 60){
                $elapsed = $elapsed . 's';
              } elseif($elapsed < 60*60){
                $elapsed = ((int) ($elapsed / 60)) . 'm';
              } elseif($elapsed < 60*60*24){
                $elapsed = ((int) ($elapsed / 60 / 60)) . 'h';
              } elseif($elapsed < 60*60*24*7){
                $elapsed = ((int) ($elapsed / 60 / 60 / 24)) . 'd';
              } else{
                $elapsed = ((int) ($elapsed / 60 / 60 / 24 / 7)) . 'w';
              }
              
              echo "<div class='notification_message'><div class='notification_icon'><img class='profile-picture-1' src='data:image;base64,".base64_encode($whofollowyouICON). "' alt='Profile Picture' /> </div><ul class='notification_word'> $whofollowyou started following you. </ul>" ;
              echo "<ul class = 'notification_time'> $elapsed </ul></div>";
                  
      
      
                
              
              }
            
          echo "</div></div>";

    ?>



<!-- 
      <div style="position: relative;" id="box">
        <div class="treehole_box">
          <div class="treehole_title">
            <span>Notification!</span>
          </div>


          <div class="notification_message">
            <div class="notification_icon">
                <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> 
            </div>
            
                <ul class ="notification_word"> abecassdas and 1232133 people like your message your tweets</ul>
                <ul class ="notification_time"> 4m</ul>
            </div>
        



          <div class="notification_message">
            <div class="notification_icon">
                <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> 
            </div>
            
                <ul class ="notification_word"> abecassdas and 1232133 people like your message your tweets</ul>
                <ul class ="notification_time"> 4m</ul>
            </div>

        

            <div class="notification_message">
                <div class="notification_icon">
                    <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> 
                </div>
                
                    <ul class ="notification_word"> abecassdas and 1232133 people like your message your tweets</ul>
                    <ul class ="notification_time"> 4m</ul>
                </div>



                <div class="notification_message">
                    <div class="notification_icon">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> 
                    </div>
                    
                        <ul class ="notification_word"> abecassdas and 1232133 people like your message your tweets</ul>
                        <ul class ="notification_time"> 4m</ul>
                    </div>



                    <div class="notification_message">
                        <div class="notification_icon">
                            <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> 
                        </div>
                        
                            <ul class ="notification_word"> abecassdas and 1232133 people like your message your tweets</ul>
                            <ul class ="notification_time"> 4m</ul>
                        </div>

                    <div class="notification_message">
                    <div class="notification_icon">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> 
                    </div>
                    
                        <ul class ="notification_word"> abecassdas and 1232133 people like your message your tweets</ul>
                        <ul class ="notification_time"> 4m</ul>
                    </div>


                    <div class="notification_message">
                    <div class="notification_icon">
                        <img class="profile-picture-1" src="icon1.png" alt="Profile Picture" /> 
                    </div>
                    
                        <ul class ="notification_word"> abecassdas and 1232133 people like your message your tweets</ul>
                        <ul class ="notification_time"> 4m</ul>
                    </div>
        


          <div class="end_notification">
            <span>You have no more unread nofications</span>
          </div>


          </div>
        </div>
        <div class="close_box" onclick="closetreehole()"></div>
      </div>
    </div> -->
  </body>
</html>
<style>
  * {
    padding: 0;
    margin: 0;
    user-select: none;
  }



  .setting_box_bak {
    width: 500px;
    height: 500px;
    position: absolute;
    padding: 5px;
    top: 50px;
    left: calc(50vw - 250px);

    background-color: white;
    z-index: 3;
    overflow-y: auto;
    overflow-x: hidden;
    padding-top: 60px;
    padding-bottom: 30px;

  }



  .treehole_box {
    width: 32vw;
    height: 60vh;
    position: relative;
    padding: 5px;
    top: 5vh;
    left: 2vh;

    background-color: white;
    z-index: 3;
    overflow-y: auto;
    overflow-x:hidden;
    padding-top: 15px;
    padding-bottom: 5px;

  }
  .treehole_title_bak {

    /* width: 440px;
    height: 50px; */


    margin: 30px auto;
    /* background-color: white; */
    background-size: 100% 100%;
    color: #288cc6 ;
    font-size: 30px;
    font-weight: 800;
    line-height: 50px;
    text-align: center;
    position: fixed;
    top: 18vh;
    left: 22vh;
  }
  .treehole_title {
    background-color: white;
    background-size: 100% 100%;
    line-height: 50px;
    font-size: 30px;
    font-weight: 800;
    line-height: 50px;
    color: #288cc6 ;
    position: relative;
    text-align: center;
  }

  .notification_message {
    display: block;
    background-color: white;
    width: 95%;
    height: 60px;
    border-bottom: 2px solid rgb(159, 156, 156);
    margin-top: 5px;
    margin-left: 5px;
    background-size: 100% 100%;
    font-size: 18px;
    font-weight: 20;
    line-height: 24px;
    color: rgb(31, 31, 31);
  }

 
  /*close chat box button*/
  .close_box {
    width: 50px;
    height: 50px;
    position: absolute;
    left: calc(50vw + 195px);
    top: 210px;
    background-image: url("img/close.png");
    background-size: 100% 100%;
    z-index: 4;
  }

  .end_notification{  
    background-color: white;
    width: 100%;
    height: 60px;
    /* margin: 30px auto; */
    margin-top: 5px;
    margin-left: 5px;
    background-size: 100% 100%;
    font-size: 18px;
    font-weight: 25;
    line-height: 60px;
    text-align: center;
    color: rgb(159, 156, 156);
  }
.notification_icon {
    display: block;
  border-radius: 999999px;
  height: 49px;
  width: 49px;
  overflow: hidden;
  position: relative;
  width: 49px;
}

.profile-picture-1 {
  height: 49px;
  left: 0;
  object-fit: cover;
  position: absolute;
  top: 1px;
  width: 49px;
}
.notification_word {
    width: 88%;
    height: 60px;
    left: 55px;
    /* margin: 10px 20px; */
    text-align: left;
    bottom:35px;
    overflow: hidden;
    position: relative;
}
.notification_time{
    width: 10%;
    height: 40px;
    left: 370px;
    top:-95px;
    color: rgb(159, 156, 156);
    text-align: left;

    overflow:inherit;
    position: relative;
}


  
</style>

<script>
  function opentreehole_choice() {
    console.log(333);
    document.getElementById("choose_box").style.display = "block";
  }

  function closetreehole() {
    document.getElementById("box").style.display = "none";
  }
  function closechoose() {
    document.getElementById("choose_box").style.display = "none";
  }
  function opentreehole() {
    console.log(333);
    document.getElementById("box").style.display = "block";
  }

  function openleavemsg() {
    console.log(333);
    document.getElementById("leave_box").style.display = "block";
  }
  function closeleave() {
    document.getElementById("leave_box").style.display = "none";
  }
  function opensend() {
    closetreehole();
    closeleave();
    console.log(333);
    document.getElementById("send_box").style.display = "block";
  }
  function closesend() {
    document.getElementById("send_box").style.display = "none";
  }
</script>
