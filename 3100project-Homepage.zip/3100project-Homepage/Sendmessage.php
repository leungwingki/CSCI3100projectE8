<?php
$servername = "localhost";
$username = "root";
$password = "usbw";
$db = "tinkle";
$conn = new mysqli($servername, $username, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
                    // owner
                    $A = @$_POST['user'];
                    // partner
                    $B = @$_POST['fid'];
                    
                    echo "<br><form method='post' autocomplete='off'>";
                    echo "<input type='text' name='inputbox' class='chatApp__convInput' type='text' placeholder='Type a message...' required>";
                    echo "<input type='submit' name ='send' class ='chatApp__convButton' value='Send'></form>";
                    //sent new message
                    if(isset($_POST["send"])){
                        if($_POST["inputbox"] != ""){
                            $new = $_POST["inputbox"];
                            $sql = "INSERT INTO privatemessage(FromUserID, ToUserID, Text) VALUES($A, $B, '$new')";
                            if($conn->query($sql) == FALSE){
                                echo "error :(";
                            }
                        }
                    }

?>