$(document).ready(function () {
  $("#Notification-ID-modal").load("notification.php");
  $("#fate-ID-modal").load("yourFate.php");
});

function displayLike() {
  $(".interactimg_1").attr("src", "likeRedHeart.png");
}

function editProfile(user) {
  var update = user;
  location.href = "editProfile.php";
  console.log(update);
}

function followFunction(user) {
  var target = document.getElementsByClassName("name")[0].id;
  var follower = user;
  var choice = document.getElementById("followChoice").value;
  $.ajax({
    type: "POST",
    url: "follow.php",
    data: {
      FollowerUserID: target,
      TargetUserID: follower,
      followChoice: choice,
    },
    dataType: "json",
    success: function (data) {
      var userData = JSON.parse(data);
    },
  });

  //choice 0 stands for wanna follow, 1 stands for unfollow
  if (choice === "0") {
    // const div = document.getElementById("NoFollower");
    console.log(div);
    content(div, "whatever");
  } else {
    console.log("happy");
  }
}
