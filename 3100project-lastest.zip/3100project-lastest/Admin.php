<?php
session_start();
?>
<!DOCTYPE html>
<html>
  <head>
  <link rel="stylesheet"
		href="AdminPageStyle.css">
  </head>
  <body>
  <div class="BIGcontainer">
        <div class="sidebar" >
               <div ><img src="LOGO.png" class="logo"></div>
			  -- Welcome back, admin1! --
			  <div>
			   <form method="post">
			   <input class="searchforuser" type="text" placeholder="Username" name="search">
                 <button type="submit" name="submit" class="fa-fa-search" >Search</button>
				</form>
               </div>

               <?php 

$servername = "localhost";
$username = "root";
$password = "";
$db = "tinkle";
$conn = new mysqli($servername, $username, $password, $db);
			   
			   if(isset($_POST["submit"])){
				
				$str = $_POST["search"];
				$sth = "SELECT UserID FROM user WHERE Username='$str'";
				$result =$conn->query($sth);
       
				if($row = $result->fetch_array()){
        
          $_SESSION["targetuser"] = $row[0];
					
          header('Location: my-profile-others.php');

				}else{

					echo"Username do not exisit";

				}
     

			   }

?>
				<?php
			   $servername = "localhost";
					$username = "root";
					$password = "";
					$db = "tinkle";
			   $conn = new mysqli($servername, $username, $password, $db);
			   if ($conn->connect_error) {
				   die("Connection failed: " . $conn->connect_error);
			   }
	   
			   
			   $sql = "SELECT count(*) FROM user";
			   $test =$conn->query($sql);
			   $row = $test->fetch_array();
			   $Unum =$row[0];
			   echo "	<p>User accounts created in tinkle: $Unum </p> ";
			   $sql = "SELECT count(*) FROM tweet";
			   $test =$conn->query($sql);
			   $row = $test->fetch_array();
			   $Unum =$row[0];
			   echo "	<p>Tweets created in tinkle: $Unum </p> ";
			   $sql = "SELECT count(*) FROM report";
			   $test =$conn->query($sql);
			   $row = $test->fetch_array();
			   $Unum =$row[0];
			   echo "	<p>Received reports: $Unum </p> ";

			   

				

			   


			   ?>


			   <button class="signout" onclick="location.href='LogIn.php'">Sign Out</button>
        </div>




        <div class="Home">
            <div class="HomeTop">Reports</div>
				<script>
					function changeColour(){

					}
				</script>
				<?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$db = "tinkle";
					$conn = new mysqli($servername, $username, $password, $db);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
			
					// get following tweets and get recent popular tweets (join)
					$sql = "SELECT User.Icon, User.Username, Tweet.DateTime, Tweet.Text, Tweet.image_video, Tweet.LikeCounter, Tweet.DislikeCounter, Tweet.CommentCounter, Tweet.RetweetCounter, Tweet.TweetID, report.Reason FROM Tweet, User, Report WHERE Tweet.userid = User.userid AND Tweet.TweetID=Report.TweetID   ORDER BY DateTime DESC";
					$result = $conn->query($sql);
					date_default_timezone_set('Asia/Hong_Kong');

					// print
					while($row = $result->fetch_array()) {
						$pic1 = $row[0];
						$name = $row[1];
						$elapsed = time() - strtotime($row[2]);
						if($elapsed < 60){
							$elapsed = $elapsed . 's';
						} elseif($elapsed < 60*60){
							$elapsed = ((int) ($elapsed / 60)) . 'm';
						} elseif($elapsed < 60*60*24){
							$elapsed = ((int) ($elapsed / 60 / 60)) . 'h';
						} elseif($elapsed < 60*60*24*7){
							$elapsed = ((int) ($elapsed / 60 / 60 / 24)) . 'd';
						} else{
							$elapsed = ((int) ($elapsed / 60 / 60 / 24 / 7)) . 'w';
						}
						$message = $row[3];
						$pic2 = $row[4];
						$upc = $row[5];
						$downc = $row[6];
						$comc = $row[7];
						$rec = $row[8];
						$id = $row[9];
            $reason=$row[10];
            echo "<div class='report-container'>";
						echo "<div class='container'><div class='side'><div class='avatar-medium-1'>";
						echo "<img class='profile-picture-1' src='data:image;base64,".base64_encode($pic1). "' alt='Profile Picture' /> </div></div>";
						echo "<div class='main'><ul class='user'><li class='UserName' > @$name </li>";
						echo "<li class = 'TimeStamp'> $elapsed </li></ul>";
						echo "<ul class = 'text-content'><li> $message </li></ul>";
						if($pic2 != null){
							echo "<ul class = 'media'><li><img src='data:image;base64,".base64_encode($pic2). "' alt='Post Picture' /></li></ul>";
						}

                        if($pic2 == null){
                            echo "<ul class = 'no-media'><li></li></ul>";
                        }

						// get like/dislike status

						echo "<form method = 'post'> <ul class='action_-item'>  <li> <button type='button' name='inter1'> <img class='interactimg' src='Like.png'> </button> </li><li class='LikeCount' > $upc </li>";
						echo "<li> <button type='button' name='inter2'> <img class='interactimg' src='Dislike.png'> </button> </li><li class = 'DislikeCount'> $downc </li>";
						echo "<li> <button type='button' name='inter3'> <img class='interactimg' src='Comment.png'> </button> </li><li class='CommentCount'> $comc </li>";
						echo "<li> <button type='button' name='inter4'> <img class='interactimg' src='Retweet.png'> </button> </li><li class='RetweetCount'> $comc </li>  </ul> </form>";
						echo "</div></div>";
            echo "<div class='report-reason'>

            <div class='report-header'>Reported Reason: <div class='reason-text'>$reason</div></div>
            
            
            
            
            <div class='button'>
                        <a href='Admin.php?error=".$id."' >Keep</a><br/><a  href='Admin.php?id=".$id."'>Delete</a>
            </div>
            
            
            </div>";
            echo "</div>";
					}

          if (isset($_GET['id'])){
            $id=$_GET['id'];
              $delete=mysqli_query($conn," DELETE FROM tweet where TweetID= $id");
              $delete=mysqli_query($conn," DELETE FROM report where TweetID= $id");
              
          }
          if (isset($_GET['error'])){
            $id=$_GET['error'];
              $delete=mysqli_query($conn," DELETE FROM report where TweetID= $id");
          }
					if(isset($_POST['inter1'])){
						echo "success";
					}


				?>
        </div>
        <div class="Chat" >

                <div class="ChatList">

                    <div class="ChatListTop">User List
                        
                    </div>
                   
                    <?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$db = "tinkle";
					$conn = new mysqli($servername, $username, $password, $db);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}
			
					// get following tweets and get recent popular tweets (join)
					$sql = "SELECT User.Icon, User.Username FROM  User where Username != 'Admin1'";
					$result = $conn->query($sql);
					date_default_timezone_set('Asia/Hong_Kong');

					// print
					while($row = $result->fetch_array()) {
						$pic1 = $row[0];
						$name = $row[1];
						
						
  
						// get like/dislike status

						echo "  <div class='ListItem'>

            <div class='Listside'>
            <div class='avatar-medium-1'>
            <img class='profile-picture-1' src='data:image;base64,".base64_encode($pic1). "' alt='Profile Picture' /> </li>
            </div>
                <div class='ListUserName' > @$name
                   </div>
            </div>
            <div class='button2'>
           <a  href='Admin.php?delete=".$name."'>Delete</a>
</div>
            </div>
";
					}

          if (isset($_GET['delete'])){
            $name=$_GET['delete'];
              $delete=mysqli_query($conn," DELETE FROM user where Username='$name'");
             
              
          }
					if(isset($_POST['inter1'])){
						echo "success";
					}


				?>
        
        </div>
                       


            </div>
               
        </div>
    </div>
    </body>
</html>