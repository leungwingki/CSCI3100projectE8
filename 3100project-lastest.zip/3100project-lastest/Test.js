$(window).load(function(){
    $('#exampleModal').modal('show');
});

$(window).load(function(){
    $('#exampleModalPP').modal('show');
});