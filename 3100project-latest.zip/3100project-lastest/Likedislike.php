<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "tinkle";
    $conn = new mysqli($servername, $username, $password, $db);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $user = @$_POST['user'];
    $tid = @$_POST['tid'];
    $add_remove = @$_POST['add'];
    //like=1, dislike = 0
    $action = @$_POST['action'];
    // insert
    if($add_remove == 1){
        $sql1 = "INSERT INTO Likes_Dislikes(UserID, TweetID, Like_Dislike) VALUES($user, $tid, $action)";
        if($action == 1){
            $sql2 = "UPDATE Tweet SET likeCounter = likeCounter + 1  WHERE TweetID = $tid";
        } else{
            $sql2 = "UPDATE Tweet SET dislikeCounter = dislikeCounter + 1  WHERE TweetID = $tid";
        }
    } else{ //delete
        $sql1 = "DELETE FROM Likes_Dislikes WHERE UserID = $user AND TweetID = $tid AND Like_Dislike = $action";
        if($action == 1){
            $sql2 = "UPDATE Tweet SET likeCounter = likeCounter - 1  WHERE TweetID = $tid";
        } else{
            $sql2 = "UPDATE Tweet SET dislikeCounter = dislikeCounter - 1  WHERE TweetID = $tid";
        }
    }
    $result = $conn->query($sql1);
    $result = $conn->query($sql2);
    if($conn->query($sql1) == FALSE || $result == 0){
        echo "error :(";
    }
?>
