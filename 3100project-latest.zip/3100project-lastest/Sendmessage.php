<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "tinkle";
$conn = new mysqli($servername, $username, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
                    // owner
                    $user = @$_POST['user'];
                    // partner
                    $fid = @$_POST['fid'];
                    $text = @$_POST['text'];
                    if($text != null && $text != "" && $text != " "){
                            $sql = "INSERT INTO privatemessage(FromUserID, ToUserID, Text) VALUES($user, $fid, '$text')";
                            if($conn->query($sql) == FALSE){
                                echo "error :(";
                            }
                    }

?>